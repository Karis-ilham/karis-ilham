<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Service - Daftar Pengiriman</title>
    <link rel="stylesheet" href="service.css">
</head>
<body>
    <div class="service-container">
        <h2>Formulir Daftar Pengiriman</h2>
        <p>Silakan isi detail pengiriman di bawah ini:</p>

        <!-- Formulir pengiriman -->
        <form id="formPengiriman" action="submit_pengiriman.php" method="POST">
            <div class="form-group">
                <label for="no_resi">Nomor Resi:</label>
                <input type="text" id="no_resi" name="no_resi" required>
            </div>
            <div class="form-group">
                <label for="nama_penerima">Nama Penerima:</label>
                <input type="text" id="nama_penerima" name="nama_penerima" required>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat Lengkap:</label>
                <textarea id="alamat" name="alamat" required></textarea>
            </div>
            <div class="form-group">
                <label for="kota">Kota:</label>
                <input type="text" id="kota" name="kota" required>
            </div>
            <div class="form-group">
                <label for="provinsi">Provinsi:</label>
                <input type="text" id="provinsi" name="provinsi" required>
            </div>
            <div class="form-group">
                <label for="phone">Nomor Telepon:</label>
                <input type="tel" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label for="catatan">Catatan Tambahan (Opsional):</label>
                <textarea id="catatan" name="catatan"></textarea>
            </div>
            <div class="form-group">
                <button type="submit" id="submitBtn">Kirim Data Pengiriman</button>
            </div>
        </form>

        <div class="back-link">
            <a href="index.php">Kembali ke Home</a>
        </div>
    </div>

    <!-- Modal Pop-up -->
    <div id="modalPopup" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p>Pendaftaran Berhasil!</p>
            <button id="okBtn">OK</button>
        </div>
    </div>

    <script src="service.js"></script>
</body>
</html>
