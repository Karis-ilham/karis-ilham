// Handle register form submission
function handleRegister(event) {
    event.preventDefault(); // Prevent form submission

    // Get the values from input fields
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Save the new user details in localStorage
    localStorage.setItem('registeredUsername', username);
    localStorage.setItem('registeredPassword', password);

    // Show success message
    alert("Registrasi berhasil! Silakan login.");

    // Redirect to login page
    window.location.href = "login.php";
}

// Handle login form submission
function handleLogin(event) {
    event.preventDefault(); // Prevent form submission

    // Get the values from input fields
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Retrieve registered details from localStorage
    const registeredUsername = localStorage.getItem('registeredUsername');
    const registeredPassword = localStorage.getItem('registeredPassword');

    // Check if the entered details match the registered details
    if (username === registeredUsername && password === registeredPassword) {
        // Store logged-in username in localStorage
        localStorage.setItem('loggedInUser', username);

        // Show success pop-up
        alert("Login berhasil!");

        // Redirect to dashboard or home page
        window.location.href = "dashboard.php";
    } else {
        // Show error message
        alert("Username atau password salah!");
    }
}

// Optionally, show logged-in user on dashboard
function showLoggedInUser() {
    const loggedInUser = localStorage.getItem('loggedInUser');
    if (loggedInUser) {
        document.getElementById('welcomeMessage').textContent = `Welcome, ${loggedInUser}!`;
    }
}
