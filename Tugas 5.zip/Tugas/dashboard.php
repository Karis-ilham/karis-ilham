<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Proses Pengiriman</title>
    <link rel="stylesheet" href="dashboard.css"> <!-- Pastikan path CSS benar -->
</head>
<body>
    <div class="dashboard-container">
        <h2>Dashboard Proses Pengiriman</h2>
        <p>Berikut adalah rincian pengiriman untuk penerima:</p>
        
        <h3>Rincian Pengiriman</h3>
        <table>
            <tr>
                <th>No. Resi</th>
                <th>Nama Penerima</th>
                <th>Alamat</th>
                <th>Status</th>
                <th>Estimasi Waktu Sampai</th>
                <th>Persentase Pengiriman</th>
            </tr>

            <?php
            // Contoh data pengiriman
            $pengiriman = [
                [
                    "resi" => "1234567890",
                    "penerima" => "John Doe",
                    "alamat" => "Jl. Contoh No. 1, Jakarta",
                    "status" => "Sedang Dikemas",
                    "estimasi" => "03/10/2024 (Estimasi 2 Hari)",
                    "persentase" => 30
                ]
            ];

            // Looping data pengiriman
            foreach ($pengiriman as $data) {
                echo "<tr>";
                echo "<td>{$data['resi']}</td>";
                echo "<td>{$data['penerima']}</td>";
                echo "<td>{$data['alamat']}</td>";
                echo "<td><span class='status kemasan'>{$data['status']}</span></td>";
                echo "<td>{$data['estimasi']}</td>";
                echo "<td>
                        <div class='progress-container'>
                            <div class='progress' style='width: {$data['persentase']}%;'></div>
                        </div>
                        {$data['persentase']}%
                      </td>";
                echo "</tr>";
            }
            ?>

        </table>

        <div class="back-link">
            <a href="index.php">Kembali ke Home</a>
        </div>
    </div>
</body>
</html>
