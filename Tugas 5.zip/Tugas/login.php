<?php
// Cek apakah pengguna telah login dengan "Ingat Saya"
if (isset($_COOKIE['rememberedUsername'])) {
    $rememberedUsername = $_COOKIE['rememberedUsername'];
} else {
    $rememberedUsername = '';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>
    <link rel="stylesheet" href="loginregis.css">
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>

        <!-- Formulir login -->
        <form id="loginForm" onsubmit="handleLogin(event)">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required
                    value="<?php echo htmlspecialchars($rememberedUsername); ?>">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group remember-me">
                <input type="checkbox" id="rememberMe" name="rememberMe"
                    <?php echo isset($_COOKIE['rememberedUsername']) ? 'checked' : ''; ?>>
                <label for="rememberMe">Ingat Saya</label>
            </div>
            <div class="form-group">
                <button type="submit">Login</button>
            </div>
        </form>

        <div class="register-link">
            <p>Belum punya akun? <a href="register.php">Daftar di sini</a></p>
        </div>
    </div>

    <script>
        // Fungsi untuk menangani proses login
        function handleLogin(event) {
            event.preventDefault(); // Mencegah form submit

            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const rememberMe = document.getElementById('rememberMe').checked;

            // Ambil data yang telah terdaftar dari localStorage
            const registeredUsername = localStorage.getItem('registeredUsername');
            const registeredPassword = localStorage.getItem('registeredPassword');

            // Cek apakah username dan password cocok
            if (username === registeredUsername && password === registeredPassword) {
                // Simpan pengguna yang login di localStorage
                localStorage.setItem('loggedInUser', username);

                // Jika "Ingat Saya" dicentang, simpan di cookie
                if (rememberMe) {
                    document.cookie = "rememberedUsername=" + username + "; path=/; max-age=" + 30 * 24 * 60 * 60;
                } else {
                    document.cookie = "rememberedUsername=; path=/; max-age=0"; // Hapus cookie jika "Ingat Saya" tidak dicentang
                }

                // Tampilkan pesan berhasil
                alert("Login berhasil!");

                // Alihkan ke halaman index.php
                window.location.href = "index.php";
            } else {
                // Tampilkan pesan error jika login gagal
                alert("Username atau password salah!");
            }
        }

        // Fungsi untuk menangani proses registrasi
        function handleRegister(event) {
            event.preventDefault();

            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            // Simpan data registrasi di localStorage
            localStorage.setItem('registeredUsername', username);
            localStorage.setItem('registeredPassword', password);

            alert("Registrasi berhasil! Silakan login.");

            // Alihkan ke halaman login
            window.location.href = "login.php";
        }
    </script>
</body>
</html>
