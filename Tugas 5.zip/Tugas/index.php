<!DOCTYPE html>
<html lang="en">
<head>
    <title>Paket Mudah</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>

<?php
// Header Section
?>
<header>
    <nav>
        <div class="logo">
            <img src="Logo.png" alt="Logo">
        </div>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="service.php">Service</a></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="login.php">Login</a></li>
        </ul>
    </nav>
</header>

<?php
// About Section
?>
<section class="about-section">
    <div class="about-container">
        <div class="about-image">
            <img src="bg.png" alt="Delivery Person">
        </div>
        <div class="about-text">
            <h2>About Us</h2>
            <p>PaketMudah adalah platform pengiriman yang dirancang untuk memberikan kemudahan, kecepatan, dan efisiensi dalam mengirim barang ke seluruh penjuru negeri.
                Kami memahami bahwa pengiriman yang cepat, aman, dan terjangkau adalah kebutuhan utama, baik bagi individu maupun bisnis.
                Dengan jaringan yang luas dan layanan yang dapat diandalkan, PaketMudah hadir sebagai solusi praktis untuk semua kebutuhan pengiriman Anda.
            </p>
        </div>
    </div>
</section>

<?php
// Why Us Section
?>
<section id="why-us">
    <h2>Kenapa Memilih Paket Mudah?</h2>
    <div class="features">
        <div class="feature">
            <h3>Efisien</h3>
            <p>Kami memprioritaskan efisiensi waktu dan biaya dalam setiap pengiriman.</p>
        </div>
        <div class="feature">
            <h3>Aman</h3>
            <p>Sistem keamanan kami memastikan barang sampai dengan kondisi baik dan tepat waktu.</p>
        </div>
        <div class="feature">
            <h3>Dukungan Pelanggan</h3>
            <p>Layanan dukungan pelanggan 24/7 siap membantu.</p>
        </div>
    </div>
</section>

<?php
// Achievements Section
?>
<section id="achievements">
    <h2>Our Achievements</h2>
    <div class="achievement-list">
        <div class="achievement">
            <h3>10,000+</h3>
            <p>Paket dikirim</p>
        </div>
        <div class="achievement">
            <h3>99%</h3>
            <p>Kepuasan Pelanggan</p>
        </div>
        <div class="achievement">
            <h3>50+</h3>
            <p>Kota Tujuan Pengiriman</p>
        </div>
        <div class="achievement">
            <h3>24/7</h3>
            <p>Dukungan Pelanggan</p>
        </div>
    </div>
</section>

<?php
// Footer Section
?>
<footer>
    <p>Terima kasih telah mempercayakan pengiriman Anda kepada kami!</p>
    <div class="footer-info">
        <div class="contact-info">
            <p>Customer Service: (021) 123-4567</p>
            <p>Email: cs@paketmudah.com</p>
        </div>
        <div class="social-media">
            <p>Follow Us:</p>
            <a href="#">Instagram</a>
            <a href="#">Twitter</a>
        </div>
    </div>
</footer>

<div id="landing-container"></div>
<script src="script.js"></script>

</body>
</html>
