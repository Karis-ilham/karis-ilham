const landingSection = document.createElement('section');
landingSection.classList.add('landing-section');


const landingTitle = document.createElement('h1');
landingTitle.textContent = 'Landing Page';
landingSection.appendChild(landingTitle);

const landingDescription = document.createElement('p');
landingDescription.textContent = 'Hallo selamat datang';
landingSection.appendChild(landingDescription);

document.getElementById('landing-container').appendChild(landingSection);

function showSnackbar() {
    // Mengambil elemen snackbar
    var snackbar = document.getElementById("snackbar");

    // Menambahkan class "show" untuk menampilkan snackbar
    snackbar.classList.add("show");

    // Menghilangkan snackbar setelah 3 detik
    setTimeout(function() {
        snackbar.classList.remove("show");
    }, 3000);
}

