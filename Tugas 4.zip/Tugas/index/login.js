// Handle login form submission
function handleLogin(event) {
    event.preventDefault(); // Prevent form submission

    // Get the values from input fields
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Check if the username and password are valid (dummy check here)
    if (username === 'user' && password === 'password123') {
        // Store username in localStorage
        localStorage.setItem('loggedInUser', username);

        // Show success pop-up
        alert("Login berhasil!");

        // Redirect to dashboard or home page
        window.location.href = "dashboard.html";
    } else {
        // Show error message
        alert("Username atau password salah!");
    }
}

// Optionally, you can add a check on the dashboard to show logged-in user's name
function showLoggedInUser() {
    const loggedInUser = localStorage.getItem('loggedInUser');
    if (loggedInUser) {
        document.getElementById('welcomeMessage').textContent = `Welcome, ${loggedInUser}!`;
    }
}
