// Ambil elemen-elemen yang diperlukan
const form = document.getElementById('formPengiriman');
const modal = document.getElementById('modalPopup');
const closeBtn = document.querySelector('.close');
const okBtn = document.getElementById('okBtn');

// Fungsi untuk membuka modal pop-up
function showModal() {
    modal.style.display = 'block';
}

// Fungsi untuk menutup modal pop-up
function closeModal() {
    modal.style.display = 'none';
}

// Event listener untuk tombol "OK"
okBtn.addEventListener('click', closeModal);

// Event listener untuk menutup modal ketika tombol "X" diklik
closeBtn.addEventListener('click', closeModal);

// Menampilkan modal ketika form disubmit
form.addEventListener('submit', function(event) {
    event.preventDefault(); // Mencegah submit form normal
    showModal(); // Menampilkan modal pop-up
});
