<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Pengiriman</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <h2>Dashboard Pengiriman</h2>
        <p>Berikut adalah data pengiriman yang tersimpan:</p>

        <table>
            <thead>
                <tr>
                    <th>No. Resi</th>
                    <th>Nama Penerima</th>
                    <th>Alamat</th>
                    <th>Kota</th>
                    <th>Provinsi</th>
                    <th>Nomor Telepon</th>
                    <th>Catatan</th>
                </tr>
            </thead>
            <tbody id="dataTable">
                <!-- Data akan diisi melalui JavaScript -->
            </tbody>
        </table>

        <div class="back-link">
            <a href="service.php">Kembali ke Formulir</a>
        </div>
    </div>

    <script>
        // Ambil data dari localStorage
        const dataPengiriman = JSON.parse(localStorage.getItem('dataPengiriman')) || [];

        // Tampilkan data di tabel
        const dataTable = document.getElementById('dataTable');
        dataPengiriman.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.noResi}</td>
                <td>${item.namaPenerima}</td>
                <td>${item.alamat}</td>
                <td>${item.kota}</td>
                <td>${item.provinsi}</td>
                <td>${item.phone}</td>
                <td>${item.catatan || '-'}</td>
            `;
            dataTable.appendChild(row);
        });
    </script>
</body>
</html>
