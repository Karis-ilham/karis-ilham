<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pengiriman extends Model
{
    // Tentukan nama tabel yang digunakan
    protected $table = 'pengirimen';  // Nama tabel sesuai dengan yang ada di database

    protected $fillable = [
        'no_resi', 'nama_penerima', 'alamat', 'kota', 'provinsi', 'phone', 'catatan'
    ];
}
